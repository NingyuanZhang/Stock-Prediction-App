# Stock Prediction System
## Tech Stack
Frontend: HTML, CSS, JavaScript, jQuery, Bootstrap, ChartJS <br>
Backend: Flask, Restful API <br>
Database: MySQL <br>
Algorithms: SVM, ANN, Bayes Curve Fitting <br>

## Architecture

![architecture](architecture.png)
